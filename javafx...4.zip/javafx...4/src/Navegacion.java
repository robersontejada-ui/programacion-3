import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Navegacion {

    public static void abrirVentana(String archivo, String titulo) {

        try {

            FXMLLoader loader = new FXMLLoader(Navegacion.class.getResource(archivo));

            Scene scene = new Scene(loader.load());

            Stage stage = new Stage();

            stage.setTitle(titulo);

            stage.setScene(scene);

            stage.show();

        } catch (IOException e) {

            e.printStackTrace();

        }

    }

}
