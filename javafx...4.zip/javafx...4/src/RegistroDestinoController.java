import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

public class RegistroDestinoController {

    @FXML
    private TextField txtDestino;

    @FXML
    private ListView<Destino> listaDestinos;

    @FXML
    private Label lblMensaje;

    @FXML
    private void guardarDestino() {

        String nombre = txtDestino.getText().trim();

        if (nombre.isEmpty()) {

            lblMensaje.setText("Ingrese un destino.");
            return;

        }

        lblMensaje.setText("Guardando...");

        Thread hilo = new Thread(() -> {

            try {

                Thread.sleep(1500);

                ArchivoUtil.guardarDestino(nombre);

                Platform.runLater(() -> {

                    txtDestino.clear();

                    listaDestinos.getItems().clear();
                    listaDestinos.getItems().addAll(ArchivoUtil.leerDestinos());

                    lblMensaje.setText("Destino guardado correctamente.");

                });

            } catch (Exception e) {

                Platform.runLater(() -> lblMensaje.setText("Error al guardar."));

            }

        });

        hilo.start();

    }

    @FXML
    private void cargarDestinos() {

        listaDestinos.getItems().clear();
        listaDestinos.getItems().addAll(ArchivoUtil.leerDestinos());

        lblMensaje.setText("Destinos cargados.");

    }

}
