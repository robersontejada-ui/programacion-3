import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class ConsultaPaqueteController {

    @FXML
    private TableView<Paquete> tablaPaquetes;

    @FXML
    private TableColumn<Paquete, String> colCodigo;

    @FXML
    private TableColumn<Paquete, String> colDestinatario;

    @FXML
    private TableColumn<Paquete, Double> colPeso;

    @FXML
    private TableColumn<Paquete, String> colDestino;

    @FXML
    private Label lblMensaje;

    @FXML
    public void initialize() {

        colCodigo.setCellValueFactory(new PropertyValueFactory<>("codigo"));
        colDestinatario.setCellValueFactory(new PropertyValueFactory<>("destinatario"));
        colPeso.setCellValueFactory(new PropertyValueFactory<>("peso"));
        colDestino.setCellValueFactory(new PropertyValueFactory<>("destino"));

    }

    @FXML
    private void cargarPaquetes() {

        tablaPaquetes.getItems().clear();
        tablaPaquetes.getItems().addAll(ArchivoUtil.leerPaquetes());

        lblMensaje.setText("Paquetes cargados.");

    }

}
