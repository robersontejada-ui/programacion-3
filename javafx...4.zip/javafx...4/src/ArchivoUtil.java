import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class ArchivoUtil {

    private static final String ARCHIVO_DESTINOS = "destinos.txt";
    private static final String ARCHIVO_PAQUETES = "paquetes.txt";

    public static void guardarDestino(String nombre) throws IOException {

        FileWriter writer = new FileWriter(ARCHIVO_DESTINOS, true);

        writer.write(nombre + System.lineSeparator());

        writer.close();

    }

    public static ArrayList<Destino> leerDestinos() {

        ArrayList<Destino> lista = new ArrayList<>();

        try {

            BufferedReader reader = new BufferedReader(new FileReader(ARCHIVO_DESTINOS));

            String linea;

            while ((linea = reader.readLine()) != null) {

                if (!linea.trim().isEmpty()) {

                    lista.add(new Destino(linea));

                }

            }

            reader.close();

        } catch (IOException e) {

        }

        return lista;

    }

    public static void guardarPaquete(Paquete paquete) throws IOException {

        FileWriter writer = new FileWriter(ARCHIVO_PAQUETES, true);

        writer.write(
                paquete.getCodigo() + ";" +
                        paquete.getDestinatario() + ";" +
                        paquete.getPeso() + ";" +
                        paquete.getDestino() +
                        System.lineSeparator());

        writer.close();

    }

    public static ArrayList<Paquete> leerPaquetes() {

        ArrayList<Paquete> lista = new ArrayList<>();

        try {

            BufferedReader reader = new BufferedReader(new FileReader(ARCHIVO_PAQUETES));

            String linea;

            while ((linea = reader.readLine()) != null) {

                String[] datos = linea.split(";");

                if (datos.length == 4) {

                    lista.add(new Paquete(
                            datos[0],
                            datos[1],
                            Double.parseDouble(datos[2]),
                            datos[3]));

                }

            }

            reader.close();

        } catch (Exception e) {

        }

        return lista;

    }

}