import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;

public class ConsultaDestinoController {

    @FXML
    private ListView<Destino> listaDestinos;

    @FXML
    private Label lblMensaje;

    @FXML
    private void cargarDestinos() {

        listaDestinos.getItems().clear();
        listaDestinos.getItems().addAll(ArchivoUtil.leerDestinos());

        lblMensaje.setText("Destinos cargados.");

    }

}
