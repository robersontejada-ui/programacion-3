public class Paquete {

    private String codigo;
    private String destinatario;
    private double peso;
    private String destino;

    public Paquete() {
    }

    public Paquete(String codigo, String destinatario, double peso, String destino) {
        this.codigo = codigo;
        this.destinatario = destinatario;
        this.peso = peso;
        this.destino = destino;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getDestinatario() {
        return destinatario;
    }

    public void setDestinatario(String destinatario) {
        this.destinatario = destinatario;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }
}
