import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;

public class RegistroPaqueteController {

    @FXML
    private TextField txtCodigo;

    @FXML
    private TextField txtDestinatario;

    @FXML
    private TextField txtPeso;

    @FXML
    private ComboBox<Destino> cmbDestino;

    @FXML
    private ProgressBar progreso;

    @FXML
    private Label lblMensaje;

    @FXML
    private Button btnGuardar;

    @FXML
    private void cargarDestinos() {

        cmbDestino.getItems().clear();
        cmbDestino.getItems().addAll(ArchivoUtil.leerDestinos());

        lblMensaje.setText("Destinos cargados.");

    }

    @FXML
    private void guardarPaquete() {

        String codigo = txtCodigo.getText().trim();
        String destinatario = txtDestinatario.getText().trim();
        String pesoTexto = txtPeso.getText().trim();

        if (codigo.isEmpty()) {

            lblMensaje.setText("Ingrese el código.");
            return;

        }

        if (destinatario.isEmpty()) {

            lblMensaje.setText("Ingrese el destinatario.");
            return;

        }

        if (pesoTexto.isEmpty()) {

            lblMensaje.setText("Ingrese el peso.");
            return;

        }

        if (cmbDestino.getValue() == null) {

            lblMensaje.setText("Seleccione un destino.");
            return;

        }

        double peso;

        try {

            peso = Double.parseDouble(pesoTexto);

        } catch (NumberFormatException e) {

            lblMensaje.setText("Peso inválido.");
            return;

        }

        btnGuardar.setDisable(true);

        progreso.setProgress(0);

        Thread hilo = new Thread(() -> {

            try {

                for (int i = 1; i <= 10; i++) {

                    Thread.sleep(200);

                    double avance = i / 10.0;

                    Platform.runLater(() -> {

                        progreso.setProgress(avance);
                        lblMensaje.setText("Guardando... " + (int) (avance * 100) + "%");

                    });

                }

                Paquete paquete = new Paquete(

                        codigo,
                        destinatario,
                        peso,
                        cmbDestino.getValue().getNombre()

                );

                ArchivoUtil.guardarPaquete(paquete);

                Platform.runLater(() -> {

                    txtCodigo.clear();
                    txtDestinatario.clear();
                    txtPeso.clear();

                    progreso.setProgress(1);

                    btnGuardar.setDisable(false);

                    lblMensaje.setText("Paquete guardado correctamente.");

                });

            } catch (Exception e) {

                Platform.runLater(() -> {

                    btnGuardar.setDisable(false);

                    lblMensaje.setText("Error al guardar.");

                });

            }

        });

        hilo.start();

    }

}
