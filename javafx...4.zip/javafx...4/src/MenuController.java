import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class MenuController {

    @FXML
    private void abrirRegistroDestino() {
        Navegacion.abrirVentana("registro_destino.fxml", "Registro de Destinos");
    }

    @FXML
    private void abrirRegistroPaquete() {
        Navegacion.abrirVentana("registro_paquete.fxml", "Registro de Paquetes");
    }

    @FXML
    private void abrirConsultaDestino() {
        Navegacion.abrirVentana("consulta_destino.fxml", "Consulta de Destinos");
    }

    @FXML
    private void abrirConsultaPaquete() {
        Navegacion.abrirVentana("consulta_paquete.fxml", "Consulta de Paquetes");
    }

    @FXML
    private void demostrarProceso() {

        Stage ventana = new Stage();

        Label lblEstado = new Label("Iniciando proceso...");
        ProgressBar barra = new ProgressBar(0);

        VBox root = new VBox(20, lblEstado, barra);
        root.setAlignment(Pos.CENTER);

        Scene scene = new Scene(root, 350, 150);

        ventana.setTitle("Demostración Thread");
        ventana.setScene(scene);
        ventana.show();

        Thread hilo = new Thread(() -> {

            for (int i = 1; i <= 10; i++) {

                try {
                    Thread.sleep(300);
                } catch (InterruptedException e) {
                }

                double progreso = i / 10.0;

                Platform.runLater(() -> {

                    barra.setProgress(progreso);
                    lblEstado.setText("Proceso " + (int) (progreso * 100) + "%");

                });

            }

            Platform.runLater(() -> lblEstado.setText("Proceso terminado."));

        });

        hilo.start();

    }

    @FXML
    private void salir() {
        Platform.exit();
    }

}
